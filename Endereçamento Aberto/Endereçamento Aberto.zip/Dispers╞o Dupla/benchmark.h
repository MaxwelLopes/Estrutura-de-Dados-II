#ifndef ENCADEIN_H
#define ENCADEIN_H
#include <stdio.h>
#include "Tentativa_Linear.c"

void benchmarkInsercao(Hash *tabela, float fatorCarga, int *numRegistros, int tamanhoTabela, int numeroTeste, int PRIMO);

#endif